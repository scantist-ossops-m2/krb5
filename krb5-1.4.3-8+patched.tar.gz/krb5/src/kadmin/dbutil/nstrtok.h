/* Prototype for nstrtok */
char *nstrtok(char *, const char *delim);

